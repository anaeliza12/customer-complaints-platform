import base64
import datetime
from datetime import datetime, timedelta
import random
import uuid
import json
import boto3
import os
import re
from zoneinfo import ZoneInfo

SQS_URL = os.environ.get('SQS_URL')
sqs = boto3.client('sqs')

reclamantes_fixos = [
    {"nome": "Maria Silva", "cpf": "11111111111", "email": "maria@gmail.com"},
    {"nome": "João Santos", "cpf": "22222222222", "email": "joao@hotmail.com"},
    {"nome": "Ana Pereira", "cpf": "33333333333", "email": "ana@outlook.com"},
    {"nome": "Carlos Lima", "cpf": "44444444444", "email": "carlos@gmail.com"},
    {"nome": "Fernanda Costa", "cpf": "55555555555", "email": "fernanda@hotmail.com"}
]

frases_reclamacoes = [
    "O @pp está horrível!!! Muita LENTIDÃO, trAVando o tempo todo e dando e-r-r-o na tela de lOgIn quando tento resgatar meu sEgUrO.",
    "O financiamento do meu apartamento sumiu do aplicativo, está dando erro de login e não consigo acessar o boleto da fatura.",
    "!!!GOLPE!!! Clonaram meu cartão, tem uma fatura que é f-r-a-u-d-e pura e o vAlOr está iNdEvIdO no meu boleto de cobrança.",
    "Quero pedir o resgate do seguro da minha casa pelo app mas o valor da fatura está errado e com juros abusivos.",
    "Não consigo l-o-g-a-r no sistema!!! O aplicativo trava na autenticacao e minha s-e-n-h-a dá erro constante.",
    "Vou reclamar no BACEN pois essa divida é fraude, eu nao reconheco essa fatura e exijo a contestacao imediata.",
    "O boleto do credito imobiliario da minha c@sa veio com taxa de sEgUrO capitalizacao e um vAlOr indevido de multa.",
    "Hackearam meu acesso, mudaram a senha e o aplicativo mostra uma fraude de transferencia que eu nao fiz.",
    "App LENTO! Erro de login ao tentar entrar para ver a fatura do seguro de vida. Preciso de socorro técnico urgente.",
    "Meu financiamento imobiliario está com parcelas de juros erradas na fatura deste mês."
]

anexos_disponiveis = [
    {"nomeArquivo": "print_app.jpg", "tipo": "imagem"},
    {"nomeArquivo": "fatura.pdf", "tipo": "pdf"},
    {"nomeArquivo": "contrato.pdf", "tipo": "pdf"},
    {"nomeArquivo": "comprovante.jpg", "tipo": "imagem"}
]

def gerar_base64_fake(nome_arquivo):
    conteudo_simulado = f"Conteudo binario base64 simulado do arquivo: {nome_arquivo}"
    return base64.b64encode(conteudo_simulado.encode('utf-8')).decode('utf-8')

def normalizar_correlation_id(texto):
    if not texto:
        return str(uuid.uuid4())
    limpo = re.sub(r'[^a-z0-9]', '_', texto.lower())
    return re.sub(r'_+', '_', limpo).strip('_')

def gerar_datas_criacao():
    agora = datetime.now(ZoneInfo("America/Sao_Paulo"))
    return [
        agora,                          # No prazo
        agora - timedelta(days=12),     # SLA Vencido (mais de 10 dias)
        agora - timedelta(days=7)       # Em alerta de SLA (entre 6 e 9 dias)
    ]

def gerar_reclamacao():
    anexos_selecionados = []
    for _ in range(random.randint(0, 2)):
        base = random.choice(anexos_disponiveis)
        anexos_selecionados.append({
            "nomeArquivo": base["nomeArquivo"],
            "tipo": base["tipo"],
            "base64": gerar_base64_fake(base["nomeArquivo"])
        })

    novo_uuid = str(uuid.uuid4())
    c_id = normalizar_correlation_id(f"ext_{novo_uuid[:8]}")

    return {
        "id": str(uuid.uuid4()),
        "correlationId": c_id,
        "dataCriacao": random.choice(gerar_datas_criacao()).isoformat(),
        "cliente": random.choice(reclamantes_fixos),
        "texto": random.choice(frases_reclamacoes),
        "anexos": anexos_selecionados
    }

def lambda_handler(event, context):
    try:
        quantidade = random.randint(1, 5)
        reclamacoes = [gerar_reclamacao() for _ in range(quantidade)]
        
        agora_str = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime('%Y-%m-%d %H:%M:%S')
        print(f"[{agora_str}] Iniciando geração de {quantidade} mensagens com anexos em Base64.")

        for rec in reclamacoes:
            c_id = rec["correlationId"]
            
            print(f"Metrica:InicioProcessamento | Canal: Digital | CorrelationId: {c_id}")
            
            sqs.send_message(
                QueueUrl=SQS_URL,
                MessageBody=json.dumps(rec, ensure_ascii=False)
            )
            
            print(f"INFO - Mensagem postada com sucesso: | ID: {c_id} | Anexos: {len(rec['anexos'])}")

        return {
            "statusCode": 200,
            "body": json.dumps({
                "status": "sucesso",
                "mensagens_enviadas": quantidade,
                "timestamp": agora_str
            })
        }

    except Exception as e:
        print(f"Metrica:FalhaProcessamento | Erro: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"erro": str(e)})
        }