import os
import boto3
import psycopg2
from datetime import datetime, timedelta

def lambda_handler(event, context):
    DB_HOST = os.environ['DB_HOST']
    DB_NAME = os.environ['DB_NAME']
    DB_USER = os.environ['DB_USER']
    DB_PASS = os.environ['DB_PASS']
    SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')

    hoje = datetime.utcnow()
    conn = None
    try:
        conn = psycopg2.connect(host=DB_HOST, database=DB_NAME, user=DB_USER, password=DB_PASS)
        cur = conn.cursor()

        query = """
            SELECT "Id", "CorrelationId", "DataCriacao" 
            FROM "Reclamacoes" 
            WHERE "Status" NOT IN ('Resolvida', 'Cancelada', 'EnviadaCanal')
              AND ("UltimaNotificacaoSLA" IS NULL 
                   OR "UltimaNotificacaoSLA"::date < CURRENT_DATE)
        """
        
        cur.execute(query)
        reclamacoes = cur.fetchall()

        print(f"--- Consulta realizada em {hoje} ---")
        print(f"Total de reclamações pendentes de análise: {len(reclamacoes)}")

        notificados_neste_ciclo = 0

        for rec in reclamacoes:
            rec_id, correlation_id, data_criacao = rec
            
            dias_aberto = (hoje.date() - data_criacao.date()).days
            
            print(f"Analisando ID: {rec_id} | CorrelationId: {correlation_id} | Aberto há: {dias_aberto} dias")
            
            if dias_aberto >= 10:
                status_sla = "VIOLADO"
                sla_violado_bool = True
                mensagem = f"URGENTE: O chamado {correlation_id} ultrapassou o limite de 10 dias (Aberto há {dias_aberto} dias)."
            elif dias_aberto >= 7:
                status_sla = "ALERTA"
                sla_violado_bool = False
                mensagem = f"ATENÇÃO: O chamado {correlation_id} está próximo de vencer o SLA (Aberto há {dias_aberto} dias)."
            else:
                print(f"-> Ignorado: Dentro do prazo seguro ({dias_aberto} dias).")
                continue

            enviar_alerta_sns(SNS_TOPIC_ARN, correlation_id, mensagem, status_sla)
            notificados_neste_ciclo += 1

            cur.execute(
                """
                UPDATE "Reclamacoes" 
                SET "UltimaNotificacaoSLA" = %s,
                    "SLAViolado" = %s
                WHERE "Id" = %s
                """,
                (hoje, sla_violado_bool, rec_id)
            )
            print(f"-> Sucesso: Banco atualizado para {correlation_id} (SLA {status_sla}).")

        conn.commit()
        print(f"--- Fim do Processamento: {notificados_neste_ciclo} notificações enviadas ---")
        
        return {
            "status": "sucesso", 
            "total_encontrado": len(reclamacoes),
            "notificados": notificados_neste_ciclo
        }

    except Exception as e:
        print(f"ERRO CRÍTICO: {e}")
        return {"status": "erro", "mensagem": str(e)}
    finally:
        if conn: conn.close()

def enviar_alerta_sns(topic_arn, correlation_id, mensagem, status_sla):
    if not topic_arn:
        print(f"SIMULAÇÃO SNS [{status_sla}]: {mensagem}")
        return

    sns = boto3.client('sns')
    try:
        sns.publish(
            TopicArn=topic_arn,
            Message=mensagem,
            Subject=f"[{status_sla}] Chamado: {correlation_id}",
            MessageAttributes={
                'StatusSLA': {'DataType': 'String', 'StringValue': status_sla}
            }
        )
    except Exception as e:
        print(f"Falha ao enviar SNS para {correlation_id}: {e}")