import json
import psycopg2
from psycopg2.extras import RealDictCursor

DB_CONFIG = {
    "host": "db-complaints.cdskcq8gyujm.us-east-2.rds.amazonaws.com",
    "database": "db-complaints",
    "user": "postgres",
    "password": "---", # Use sua senha aqui
    "port": 5432
}

def lambda_handler(event, context):
    conn = None
    try:
        reclamacao = event.get('detail', {})
        
        correlation_id = reclamacao.get('CorrelationId')
        cliente = reclamacao.get('Cliente', {})
        texto = reclamacao.get('Texto')
        data_criacao = reclamacao.get('DataCriacao')
        
        print(f"Processando Reclamação: {correlation_id}")

        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()

        sql = """
            INSERT INTO "Reclamacoes" ("Id", "Texto", "DataCriacao", "Status")
            VALUES (%s, %s, %s, %s)
            ON CONFLICT ("Id") DO UPDATE SET "Texto" = EXCLUDED."Texto";
        """
        
        cur.execute(sql, (
            correlation_id, 
            texto, 
            data_criacao, 
        ))

        conn.commit()
        cur.close()

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Salvo com sucesso', 'id': correlation_id})
        }

    except Exception as e:
        print(f"Erro ao salvar no banco: {str(e)}")
        if conn:
            conn.rollback()
        raise e 

    finally:
        if conn:
            conn.close()