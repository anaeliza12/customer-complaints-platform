const express = require("express");
const app = express();

app.use(express.json());

require("./dataMesh")(app);

app.listen(5002, () => {
  console.log("Servidor único rodando em http://localhost:5002");
  console.log("DataMesh:     /datamesh/clientes/:cpf");
});
