const express = require("express");
const app = express();

app.use(express.json());


const clientes = [
  {
    cpf: "11111111111",
    nome: "Maria Silva",
    scoreCredito: 680,
    produtos: ["Cartão de Crédito", "Empréstimo Pessoal"],
    UltimaNotificacaoSLA: "2024-10-05",
    relacionamentoAnos: 4,
    risco: "medio"
  },
  {
    cpf: "22222222222",
    nome: "João Santos",
    scoreCredito: 750,
    produtos: ["Cartão de Crédito", "Financiamento Veicular"],
    UltimaNotificacaoSLA: "2023-08-12",
    relacionamentoAnos: 7,
    risco: "baixo"
  },
  {
    cpf: "33333333333",
    nome: "Ana Pereira",
    scoreCredito: 610,
    produtos: ["Conta Corrente"],
    UltimaNotificacaoSLA: "2024-12-01",
    relacionamentoAnos: 2,
    risco: "alto"
  },
  {
    cpf: "44444444444",
    nome: "Carlos Lima",
    scoreCredito: 700,
    produtos: ["Cartão Platinum", "Investimentos"],
    UltimaNotificacaoSLA: "2022-05-20",
    relacionamentoAnos: 10,
    risco: "baixo"
  },
  {
    cpf: "55555555555",
    nome: "Fernanda Costa",
    scoreCredito: 640,
    produtos: ["Cartão", "Empréstimo Consignado"],
    UltimaNotificacaoSLA: "2024-01-15",
    relacionamentoAnos: 3,
    risco: "medio"
  }
];

module.exports = (app) => {
app.get("/datamesh/clientes/:cpf", (req, res) => {
  const { cpf } = req.params;

  const cliente = clientes.find(c => c.cpf === cpf);

  if (!cliente) {
    return res.status(404).json({
      mensagem: "Cliente não encontrado no Data Mesh"
    });
  }

  res.json(cliente);
});

app.listen(5002, () => {
  console.log("Data Mesh fake rodando em http://localhost:5002");
});
}